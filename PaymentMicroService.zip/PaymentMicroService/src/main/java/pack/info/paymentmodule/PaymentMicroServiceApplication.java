package pack.info.paymentmodule;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PaymentMicroServiceApplication {

	public static void main(String[] args) {

		SpringApplication.run(PaymentMicroServiceApplication.class, args);

	}

}
