package pack.info.paymentmodule;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PaymentMicroServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
